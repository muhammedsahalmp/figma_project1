// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    // Future interactions can be added here
});

